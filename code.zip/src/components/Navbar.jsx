"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";

const links = ["Home", "About", "Projects", "Contact"];

const Navbar = () => {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);

  return (
    <header className="fixed top-0 left-0 w-full z-50 bg-[#1C1B22]/80 backdrop-blur-md ">
      
      <div className="max-w-6xl mx-auto flex items-center justify-between p-4">

     
        <h1 className="text-white font-bold text-2xl">
          Bilal<span className="text-green-400">.</span>
        </h1>

        <nav className="hidden md:flex gap-8">
          {links.map((item, i) => {
            const path = item === "Home" ? "/" : `/${item.toLowerCase()}`;
            const isActive = pathname === path;

            return (
              <Link
                key={i}
                href={path}
                className="relative font-medium transition"
              >
                <span
                  className={
                    isActive
                      ? "text-green-400"
                      : "text-gray-300 hover:text-green-400"
                  }
                >
                  {item}
                </span>

                <span
                  className={`absolute left-0 -bottom-1 h-[2px] bg-green-400 transition-all duration-300 ${
                    isActive ? "w-full" : "w-0"
                  }`}
                />
              </Link>
            );
          })}
        </nav>

    
        <button className="bg-green-400 text-black px-5 py-2 rounded-full hover:bg-green-500 transition">
          Hire Me
        </button>

        
        <button
          onClick={() => setOpen(!open)}
          className="md:hidden text-white text-2xl"
        >
          ☰
        </button>

      </div>

    
      {open && (
        <div className="md:hidden bg-[#1C1B22] border-t border-gray-800 px-6 py-4 flex flex-col items-center gap-4">

          {links.map((item, i) => {
            const path = item === "Home" ? "/" : `/${item.toLowerCase()}`;
            const isActive = pathname === path;

            return (
              <Link
                key={i}
                href={path}
                onClick={() => setOpen(false)}
                className="relative font-medium transition"
              >
                <span
                  className={
                    isActive
                      ? "text-green-400"
                      : "text-gray-300 hover:text-green-400"
                  }
                >
                  {item}
                </span>

                <span
                  className={`absolute left-0 -bottom-1 h-[2px] bg-green-400 transition-all duration-300 ${
                    isActive ? "w-full" : "w-0"
                  }`}
                />
              </Link>
            );
          })}

         
          <button className="w-full bg-green-400 text-black px-5 py-3 rounded-full mt-2 font-semibold hover:bg-green-300 transition">
            Hire Me
          </button>

        </div>
      )}

    </header>
  );
};

export default Navbar;