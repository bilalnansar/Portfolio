"use client";

import { motion } from "framer-motion";

const stairsVariants = {
  initial: { y: "0%" },
  animate: { y: "100%" },
  exit: { y: ["100%", "0%"] },
};

const Stairs = () => {
  return (
    <div className="fixed top-0 left-0 w-full h-full flex z-50 pointer-events-none">
      {[...Array(6)].map((_, i) => (
        <motion.div
          key={i}
          variants={stairsVariants}
          initial="initial"
          animate="animate"
          exit="exit"
          transition={{
            duration: 0.5,
            delay: i * 0.1,
            ease: "easeInOut",
          }}
          className="w-full h-full bg-white relative"
        />
      ))}
    </div>
  );
};

export default Stairs;