"use client";

export default function BackgroundFX() {
  return (
    <div className="fixed inset-0 -z-10 bg-[#1C1B22] overflow-hidden">

      <div className="absolute w-[250px] h-[250px] bg-green-500/10 rounded-full blur-3xl animate-pulse top-20 right-10"></div>


    </div>
  );
}