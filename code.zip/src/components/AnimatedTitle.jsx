"use client";

import { useEffect, useState } from "react";

const text = "Web Developer";

export default function AnimatedTitle() {
  const [displayText, setDisplayText] = useState("");
  const [index, setIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setDisplayText(text.slice(0, index + 1));
      setIndex((prev) => prev + 1);

     
      if (index === text.length) {
        setDisplayText("");
        setIndex(0);
      }
    }, 300); 

    return () => clearInterval(interval);
  }, [index]);

  return (
    <h2 className="text-4xl md:text-6xl font-bold text-white">
      a <span className="text-green-400">{displayText}</span>
      <span className="animate-pulse">|</span>
    </h2>
  );
}