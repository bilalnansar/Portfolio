"use client";

import { AnimatePresence } from "framer-motion";
import { usePathname } from "next/navigation";
import Stairs from "./Stairs";

const StairEffect = () => {
  const pathname = usePathname();

  return (
    <AnimatePresence mode="wait">
      <Stairs key={pathname} />
    </AnimatePresence>
  );
};

export default StairEffect;