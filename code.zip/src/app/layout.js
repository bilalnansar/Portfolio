import "./globals.css";
import Navbar from "@/components/Navbar";
import Staireffect from "@/components/Staireffect";
import PageTransition from "@/components/PageTransition";
import BackgroundBlobs from "@/components/BackgroundBlobs";

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body className="bg-[#1C1B22] text-white overflow-x-hidden">

       
        <Navbar />
        
<BackgroundBlobs />
        
        <Staireffect />

        
        <PageTransition>
          <main className="pt-24">
            {children}
          </main>
        </PageTransition>

      </body>
    </html>
  );
}