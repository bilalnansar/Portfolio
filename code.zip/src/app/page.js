"use client";

import { motion } from "framer-motion";
import Image from "next/image";
import AnimatedTitle from "@/components/AnimatedTitle";

import { CiSaveDown2 } from "react-icons/ci";
import { FaFacebook, FaGithub, FaGlobe, FaLinkedin } from "react-icons/fa";

const page = () => {
  return (
    <div className="w-full min-h-screen flex items-center justify-center bottom-17 left-5 relative px-6 py-10">

      <div className="w-full max-w-6xl flex flex-col md:flex-row items-center gap-12">

        
        <div className="flex-1 text-center md:text-left">

          <h5 className="text-gray-400 mb-2">Hey there!</h5>

          <h2 className="text-4xl md:text-6xl font-bold leading-tight text-white">
            I'm <span className="text-green-400">Bilal Ansar</span>, <br /></h2>
            <AnimatedTitle />
          

          <p className="text-gray-300 mt-5 text-sm md:text-base leading-relaxed max-w-lg mx-auto md:mx-0">
           I am a Full Stack Developer passionate about building modern,
responsive and scalable web applications. I specialize in creating
clean UI designs, strong backend systems, and high-performance
web applications that deliver great user experience.
          </p>

          <a href="/resume.pdf" download>
            <button className="mt-6 px-6 py-3 border border-green-500 text-green-400 rounded-full hover:bg-green-500 hover:text-black transition flex items-center gap-2 hover:scale-105 duration-300 mx-auto md:mx-0">
              <CiSaveDown2 size={20} />
              Download CV
            </button>
          </a>

          <div className="flex gap-4 mt-7 justify-center md:justify-start">

            <a href="https://facebook.com" target="_blank"
              className="w-12 h-12 border border-green-500 text-green-400 rounded-full flex items-center justify-center hover:bg-green-500 hover:text-black transition hover:scale-105 duration-300">
              <FaFacebook />
            </a>

            <a href="https://linkedin.com" target="_blank"
              className="w-12 h-12 border border-green-500 text-green-400 rounded-full flex items-center justify-center hover:bg-green-500 hover:text-black transition hover:scale-105 duration-300">
              <FaLinkedin />
            </a>

            <a href="https://github.com" target="_blank"
              className="w-12 h-12 border border-green-500 text-green-400 rounded-full flex items-center justify-center hover:bg-green-500 hover:text-black transition hover:scale-105 duration-300">
              <FaGithub />
            </a>

            <a href="https://yourwebsite.com" target="_blank"
              className="w-12 h-12 border border-green-500 text-green-400 rounded-full flex items-center justify-center hover:bg-green-500 hover:text-black transition hover:scale-105 duration-300">
              <FaGlobe />
            </a>

          </div>

        </div>

    
        <div className="flex-1 flex justify-center">

          <div className="relative w-[300px] h-[300px] xl:w-[500px] xl:h-[500px] flex items-center justify-center">

    <motion.svg
  className="absolute w-full h-full"
  viewBox="0 0 500 500"
  initial={{ opacity: 0 }}
  animate={{ opacity: 1 }}
  transition={{
    delay: 0.6,   
    duration: 0.5,
    ease: "easeInOut",
  }}
>
  <motion.circle
    cx="250"
    cy="250"
    r="200"
    fill="transparent"
    stroke="#22c55e"
    strokeWidth="3"
    strokeLinecap="round"
    strokeDasharray="15 20"
    initial={{ rotate: 0 }}
    animate={{
      rotate: 360,
      strokeDasharray: ["15 20", "40 10", "15 20"],
    }}
                       

    transition={{
      duration: 6,
 
      repeat: Infinity,
      ease: "linear",
    }}
    style={{ originX: "50%", originY: "50%" }}
  />
</motion.svg>

          
            <motion.div
              initial={{ opacity: 0 }}
              animate={{
                opacity: 1,
                transition: { delay: 1, duration: 0.4, ease: "easeIn" },
              }}
            >
              <div className="w-[250px] h-[250px] xl:w-[350px] xl:h-[350px] mix-blend-lighten relative">

                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{
                    opacity: 1,
                    transition: { delay: 2.4, duration: 2.4, ease: "easeInOut" },
                  }}
                />

                <Image
                  src="/profile.png"
                  fill
                  alt="profile"
                  className="object-contain rounded-full"
                />

                <motion.div />
                <motion.div />

              </div>
            </motion.div>

          </div>

        </div>

      </div>
    </div>
  );
};

export default page;