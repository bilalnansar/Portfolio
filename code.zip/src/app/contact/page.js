"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { FaPhoneAlt, FaEnvelope, FaMapMarkerAlt } from "react-icons/fa";

export default function ContactPage() {
  const [result, setResult] = useState("");

  const onSubmit = async (event) => {
    event.preventDefault();
    setResult("Sending...");

    const formData = new FormData(event.target);
    formData.append("access_key", "273cbd5c-aad2-4805-acd6-9e7e98623836");

    const response = await fetch("https://api.web3forms.com/submit", {
      method: "POST",
      body: formData,
    });

    const data = await response.json();

    if (data.success) {
      setResult("Message sent successfully");
      event.target.reset();
    } else {
      setResult("Something went wrong");
    }
  };

  return (
    <section className="min-h-screen bg-[#1C1B22] text-white flex items-center bottom-17 left-5 relative justify-center px-4 py-16">
      
      <div className="max-w-6xl w-full grid grid-cols-1 lg:grid-cols-2 gap-10">

        {/* LEFT FORM */}
        <motion.div
          initial="hidden"
          animate="show"
          variants={{
            hidden: {},
            show: {
              transition: {
                staggerChildren: 0.15, // 🔥 one by one animation
              },
            },
          }}
          className="bg-[#1C1B22] p-8 rounded-2xl border border-white/10 shadow-lg"
        >

          <motion.h2
            variants={{ hidden: { opacity: 0, y: 20 }, show: { opacity: 1, y: 0 } }}
            className="text-2xl md:text-3xl font-bold text-green-400 mb-3"
          >
            Let&apos;s work together
          </motion.h2>

          <motion.p
            variants={{ hidden: { opacity: 0 }, show: { opacity: 1 } }}
            className="text-gray-400 text-sm mb-6"
          >
            Have a project in mind? Send me a message and I’ll respond as soon as possible.
          </motion.p>

          <form onSubmit={onSubmit} className="space-y-4">

            <motion.div
              variants={{ hidden: { opacity: 0, y: 20 }, show: { opacity: 1, y: 0 } }}
              className="grid grid-cols-1 md:grid-cols-2 gap-4"
            >
              <input type="text" name="firstname" placeholder="Firstname" required
                className="w-full bg-[#1C1B22] border border-white/10 rounded-lg px-4 py-2 text-sm outline-none focus:border-green-400"
              />
              <input type="text" name="lastname" placeholder="Lastname" required
                className="w-full bg-[#1C1B22] border border-white/10 rounded-lg px-4 py-2 text-sm outline-none focus:border-green-400"
              />
            </motion.div>

            <motion.div
              variants={{ hidden: { opacity: 0, y: 20 }, show: { opacity: 1, y: 0 } }}
              className="grid grid-cols-1 md:grid-cols-2 gap-4"
            >
              <input type="email" name="email" placeholder="Email address" required
                className="w-full bg-[#1C1B22] border border-white/10 rounded-lg px-4 py-2 text-sm outline-none focus:border-green-400"
              />
              <input type="text" name="phone" placeholder="Phone number"
                className="w-full bg-[#1C1B22] border border-white/10 rounded-lg px-4 py-2 text-sm outline-none focus:border-green-400"
              />
            </motion.div>

            <motion.div
              variants={{ hidden: { opacity: 0, y: 20 }, show: { opacity: 1, y: 0 } }}
              className="relative"
            >
              <select
                name="service"
                className="w-full bg-[#1C1B22] border border-white/10 rounded-xl px-4 py-2 text-sm outline-none focus:border-green-400 text-gray-400 appearance-none"
              >
                <option>Select a service</option>
                <option>Web Development</option>
                <option>UI/UX Design</option>
                <option>Backend Development</option>
                <option>SEO</option>
              </select>

              <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-gray-400">
                ▼
              </div>
            </motion.div>

            <motion.textarea
              name="message"
              rows="4"
              placeholder="Type your message..."
              required
              variants={{ hidden: { opacity: 0, y: 20 }, show: { opacity: 1, y: 0 } }}
              className="w-full bg-[#1C1B22] border border-white/10 rounded-lg px-4 py-2 text-sm outline-none focus:border-green-400 resize-none"
            />

            <motion.button
              type="submit"
              variants={{ hidden: { opacity: 0, scale: 0.9 }, show: { opacity: 1, scale: 1 } }}
              className="bg-green-400 text-black font-semibold px-6 py-3 rounded-full hover:bg-green-500 transition w-full"
            >
              Send message
            </motion.button>

            {result && (
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-sm text-center text-green-400 mt-2"
              >
                {result}
              </motion.p>
            )}

          </form>
        </motion.div>

        {/* RIGHT INFO */}
        <motion.div
          initial={{ opacity: 0, x: 50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.5, duration: 0.5 }}
          className="flex flex-col justify-center gap-5"
        >
          <div className="flex items-center gap-4 bg-[#1C1B22] p-5 rounded-xl border border-white/10">
            <FaPhoneAlt className="text-green-400" />
            <p>( +92 ) 3317175792</p>
          </div>

          <div className="flex items-center gap-4 bg-[#1C1B22] p-5 rounded-xl border border-white/10">
            <FaEnvelope className="text-green-400" />
            <p>hafizbilalansar675@gmail.com</p>
          </div>

          <div className="flex items-center gap-4 bg-[#1C1B22] p-5 rounded-xl border border-white/10">
            <FaMapMarkerAlt className="text-green-400" />
            <p>Gulberg, Faisalabad</p>
          </div>
        </motion.div>

      </div>
    </section>
  );
}